# @matumi/tokens

Heartwood's design tokens. `tokens.json` is the source, copied unchanged from the Heartwood design
system. What each token is for is in [the tokens section](../../../docs/design/1-tokens.md).
`pnpm build` generates the other two files; do not edit them.

| File | What |
|---|---|
| `tokens.css` | Every token as a CSS variable named after the token (`--bg-page`, `--space-4`), in four themes: `light`, `dark`, `light-safe`, `dark-safe`. Set the theme with `data-theme` on any element. |
| `theme.css` | The Tailwind 4 theme. Maps the tokens into Tailwind and switches off its defaults, so `bg-bg-surface`, `p-4` and `text-body` work and `bg-blue-500` or `p-5` produce nothing. Adds `dark:` and `vision:` variants that follow `data-theme`. |

`scripts/tailwind.test.mjs` compiles `theme.css` with the installed Tailwind and checks which
utilities exist. What it found with Tailwind 4.3.5:

- The colour, spacing, radius, shadow, type and font resets work. `--spacing-*: initial` also
  removes the spacing base, so off-scale steps such as `p-5` and `w-64` fail as intended.
- It also removed zero, so `p-0`, `m-0` and `inset-0` failed. `--spacing-0: 0px` brings it back.
- Font weight, line height, letter spacing and container widths are not reset: `font-bold`,
  `leading-tight`, `tracking-wide` and `max-w-md` still compile to Tailwind's values.
