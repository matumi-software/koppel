# @heartwood/ui

Heartwood's React components, built on react-aria-components. The styles are the design system's
own stylesheet: the components set its classes and RAC sets the `data-*` state attributes it reads.
How each component is used, and the rules for the app shell, are in the design system's
[component guidelines](../../../docs/design/components).

## Use it in an app

```css
/* app.css */
@import "tailwindcss";                  /* optional, for the app's own layout */
@import "@heartwood/tokens/tokens.css";
@import "@heartwood/tokens/theme.css";     /* only with Tailwind */
@import "@heartwood/ui/heartwood.css";
```

```html
<html data-theme="dark">
  <body class="hw">
```

- `data-theme` is `light`, `dark`, `light-safe` or `dark-safe`. The two `-safe` themes are colour
  vision mode. With no `data-theme` the page follows the system's light or dark setting.
- `class="hw"` on the body turns on the shared focus ring, disabled treatment and reduced motion,
  for overlays too.
- Fonts: Instrument Sans (400, 500, 600) and JetBrains Mono (400). The app bundles them, for
  example from `@fontsource`.
- Icons are lucide components: `<Button icon={Plus}>Share device</Button>`.
- The AppShell mounts the toast region (`toasts={false}` to leave it out, or mount `<ToastRegion />` yourself) and `toast({ title, tone, action: { label, onAction } })` shows one anywhere; `toast.dismiss`, `toast.dismissAll` and `toast.update` follow it.
- `ThemeScope` gives a region its own theme, and overlays opened inside it keep that theme. Apps
  rarely need it; the gallery uses it to show four themes side by side.

## What is here

AppShell and ListDetail, Sidebar and NavButton, TabBar, PageHeader, Tabs, Button, IconButton
(two-line tooltip), Tip and Tooltip, TextField, TextArea, NumberField, SearchField, Select,
SegmentedControl, RadioGroup, Checkbox, Switch, List and ListRow, Table, Menu, Popover, Dialog,
ToastRegion, Callout, EmptyState, ProgressBar, Skeleton, KpiCard, Tile and TileGrid, StatusGlyph,
StatusDot, Badge, StateLabel, ThemeSwitcher (menu variant), TrayWindow, BrandSlot and Logo,
TileStack, DrillLink, CopyValue, Value, SettingsList and SettingRow, the standard pieces Facts,
ScriptEditor, PauseChip, AudioPlayer, Timeline and VirtualList (scripts read aloud, their audio and long lists),
NeedsYouTile, Checklist, StripJob and PairingCode, and the standard pages: ActivityPage,
ActivityLog and ActivityTile, SettingsPage and ThirdPartyNotices. Layout primitives: Row, Stack, Grid,
Spacer, HeaderRow, HelpText, InlineError, VisuallyHidden, Mono and Tabular, with `breakpoints.phone` (640),
`usePhone()` and `useShellMode()`; also Link (`external`), `announce()` and LiveText, `formatDuration()` and
`formatRelative()`; and `useAudioSource(url)`, the audio element and state an AudioPlayer needs. The design system
describes the rest (ComboBox, Tag, Avatar, WindowChrome); they come next.

Shell, dialogs and pages (design v107 to v109): ConfirmDialog, Card (`meta`), CodeField, Toolbar, QueryState and
PageLoading. AppShell takes `activity` (the running job, a row under the top bar on a phone), `pageTitle`, `focusMain`,
`mainId`, `skipLink`, and `isLoading` or `error` for its frame; it measures its own box against `breakpoints.phone`.
Dialog takes `onSubmit`, `submitLabel` and `isSubmitDisabled`; the first control takes the focus and Close is the last
tab stop. SettingRow takes `pending`, `error`, `note` and `noteTone`, and names its control through a context. The
standard pages take `isLoading`, `error` and `onRetry`, and PeoplePage and AccountPage take `isDisabled` with a
reason per action (`remove`, `reset`, `signOut`, `passwordAction`, `userNameAction`). SignInPage handles `newPassword`
(asked twice), `setupToken` and `codeLength` (a CodeField). PageHeader takes `fields`, Inspector `disabled`, `error` and
`rail`, and a third-party notice `url` and `text`.

Sizes: controls are 32 by default. Primary and destructive buttons are 40, and so is every button
in their row: dialog footers and page header actions set that through the stylesheet.

## The app shell

Every app renders its screens inside one `AppShell`: the sidebar and a strip on one frame, the
page in an inset panel.

```tsx
<AppShell platform="windows" brand={koppel} flush nav={groups}
  toolbarEnd={<StatusDot tone="success">Sharing on</StatusDot>}
  onMinimize={...} onMaximize={...} onClose={...}>
  <ListDetail title="On studio-pc" filter={<SearchField placeholder="Search devices" width="100%" />}
    list={<List ...>...</List>}>{detail}</ListDetail>
</AppShell>
```

What the shell does, so no app decides it:

- Frame: the sidebar and the strip sit on `bg-surface` with no lines between them. The page sits
  in a `bg-page` panel with a `border-default` edge and `radius-lg` corners, 8 from the window's
  right and bottom edges and flush with the sidebar.
- Sidebar: full height, 240 wide. Its 48 high head holds the brand and, at its right edge, the
  collapse toggle (Ctrl B, Cmd B on macOS). The toggle shows only while the pointer is over the
  sidebar head or the strip, or while it has keyboard focus, and always on touch; hidden, it keeps
  its place. It collapses to icons at 48, and then the mark is the
  expand button, showing the panel icon on hover or focus. Focus follows to whichever button
  replaces the one pressed. Below 1024 wide it collapses on its own and above it expands again,
  until the person uses the toggle: their choice wins at every width and is remembered under
  `storageKey`. A labelled nav group is a
  named `group` for assistive tech, and collapsed its label becomes a divider. Leave `nav` out for
  an app with one place, and the brand sits at the strip's left.
- Strip: 48 high, level with the sidebar head. `toolbar` at the left, `toolbarEnd` at the right,
  then the window buttons on Windows. On the desktop it and the sidebar head are the drag area
  (`data-tauri-drag-region`). On macOS the system draws the traffic lights; the shell keeps their
  space in the sidebar head, or at the strip's start when the sidebar is collapsed. Its items line
  up with the content's 24 inset. Every control in it is 32.
- Content: one inset of 24 on every side inside the panel; `flush` drops it for a ListDetail or a
  viewport, whose detail pane keeps the same 24. `hw-content-inner` is a column with a 24 gap and
  takes the panel's full width: no max width, no centring.
- Inspector: pass `inspector={<Inspector ...>}` and the page panel lays the content and the drawer
  side by side, the drawer at its right edge, full height. Below about 760 of panel it opens
  over the content. On a screen that is already a ListDetail it starts as the rail
  (`defaultOpen={false}`). Anything you put between the panel and the content takes the full
  width (`width: 100%`, or `flex: 1; min-width: 0` in a row): the narrow rule and tile spans are
  container queries, and a wrapper that shrinks to its content measures itself, not the panel.
  A `choice` row is segmented, the options sharing its width equally, when its labels fit (see
  below); otherwise, or with Mixed, a select. A number that may be emptied is `nullable` (empty gives null), with `emptyLabel`
  saying what empty means ("No limit"); `note` and `noteTone` put a line under the row that stays
  visible. With `staged`, pass `invalid` while a field holds a value that cannot be applied: Apply
  stays disabled and the field says why.
- Phone: below 640 wide (or with `phone`) the top bar holds the brand and `toolbarEnd`
  (`phoneEnd` for a shorter form), the panel runs full width with a 16 inset, and the places move
  to a `TabBar` at the bottom: up to five, or four and a More tab. Tab labels stay on one line;
  give a nav item a `shortLabel` when its label runs past about 10 characters.
- The shell fills its container. `framed` adds the preview border, for galleries.

What goes where follows the rules in the
[AppShell guideline](../../../docs/design/components/AppShell/README.md):

- `toolbarEnd`, right: only what is constant through the app, in this order, each only if the app
  has it: the one running job (`hw-app-activity`, `role="status"`), app-wide state as one
  StatusDot, an app-wide scope picker (two thirds of `size-width-xs`), the theme switcher.
- `toolbar`, left: at most three icon-only tools that act on the whole page, such as undo and
  redo; most apps put nothing here. No primary buttons in the strip: the page's actions go in its
  PageHeader, list head or detail header.
- No search in the strip. Search goes in the page it searches: a ListDetail's `filter`, or the
  PageHeader actions above a table or a log. Pages with nothing to search have none.
- Sidebar: groups the way ClaudeP does. The first group has no label and holds the everyday
  places; each further group has a one word label (Configure, Library, Manage). Two to five items
  a group, at most three groups. Settings is the last item of Configure; the foot holds only the
  account menu.
- Content: a page, an overview, a ListDetail or a workspace, across the panel's full width. Fields
  keep their own widths inside their rows. PageHeader, then 24, sections 32 apart, 16 inside a
  section. One primary action per view, at 40. A PageHeader `description` may hold a CopyValue.
- Overview, for an app that watches several kinds of things: a PageHeader whose description says
  the state in a sentence, a `Tile tone="attention"` for Needs you when something does, then a
  `TileGrid` of tiles that each lead to a full page. The grid fixes the sizes: equal columns at
  least 240 wide, at most three, 24 apart; a tile spans 1, 2 or `"full"`, never a width of its
  own. Outside a grid, tiles stack full width, 24 apart.
- `ListDetail` titles the list by its scope, never the nav label. Use a `List` with
  `selectionMode="single"` so Up and Down change the detail.
- Below 800 wide, and on a phone, a ListDetail shows one pane at a time. Pass `showDetail` when
  an item is opened and `onBack` to close it; the detail gets a back button and focus moves with
  the pane. There, give the List `selectionMode="none"` and open the detail from `onAction`, so
  Up and Down move focus and Enter or a press opens.
- Drill in, to open a thing from a summary into its own view in the same place: `useDrill()` holds
  the stack for one place (`open`, `back`, `reset`, `top`, `depth`, `dir`), `DrillView` plays the
  slide, `PageHeader back={{ label: "Overview", onPress: drill.back }}` draws the link back, and
  `ListRow drill` draws the chevron. Back restores the scroll and focus on the opened row, and
  works by Alt Left (Cmd [ with `mac`), the mouse back button, and with `history` the browser's
  Back. Press the place in the sidebar again to `reset`. At most three levels. Only a move between
  levels slides: the first view, a sidebar visit, a reload or a deep link (`useDrill({ initial })`)
  shows at once.
- Pages every app has are Heartwood components, configured with the app's own events, words and
  scope, never rebuilt per app. A second app needing a page the first already has is the cue to
  raise it for Heartwood first. Activity is the first: `ActivityPage` for the place in the
  sidebar (search with Ctrl K, Export to CSV, Time, Event and Result), `ActivityLog` inside another
  page (a device's History), `ActivityTile` on the overview (the latest five and All activity).
  `activityCsv` builds the same CSV for an app that saves it its own way (`onExport`). `filters`
  puts the app's Selects in a row under the header (the app filters the events it passes), and
  `inputRef` hands over the search input for an app-wide Ctrl K. The log is a Tile (`span` like
  any tile) with its tools in the head and the table flush in the body. Below 600 wide the table
  stacks: no head, time and result on the first line, the event under them, no sideways scroll.
- Activity `states` takes the product's state map: a result whose label is in it shows as that
  StateLabel, keeping its shape in colour vision; others are a StatusDot with a tone and an
  optional shape. With `inputRef` the page leaves Ctrl K to the app's own handler.
- `Tile flush` drops the body padding, for a code view or a log. A Needs you action can be
  `disabled` or `pending`. PairingCode always shows its countdown ("Valid for 9 min 58 s, works
  once."), with `note` as a line under it. A ghost Button takes `danger` for danger text, though
  Remove and Delete are now the `IconButton danger` trash icon; `DrillLink mono` is for an id.
- A nav item with `menu` opens that Menu above itself instead of navigating: the account item in
  the sidebar foot (Sign out). Menu items act on `onAction`. A RadioGroup whose question the page
  header already asks takes `labelHidden`.
- Property: a `choice` is segmented for two options of up to 10 characters or three of up to 7,
  otherwise a select (`select` still forces one). A readonly row with `copy` is a CopyValue; a
  text row takes `mono`. Letters typed into a number row show its error state ("Type a number.")
  and the last good value stays, rather than reading as empty.
- `SignInPage` is the page every app shows when signed out: the wordmark at 32, a header ("Sign in
  to ..." and one reason line), then one Tile titled by mode (`tileTitle`: Credentials, the
  password or code label, This browser, Sign-in link) holding exactly one primary action, in a 440
  column with no sidebar. A field whose name the tile title says drops its visible label and keeps
  it as its accessible name (`TextField ariaLabel`). Inside an AppShell, `hideBrand` leaves the
  brand out of the title bar and the phone's top bar so the page's own wordmark is the only one. Form mode
  (`onSubmit`) takes a user name (`hideUser` for a single admin password) and a password and
  hands over `{ user, password }`; launch mode (`onLaunch`) is one primary with the `log-in` icon
  and a fallback line with the command as a CopyValue. With only a `fallback` the one action is
  the command, in a copyable box (never a button that only explains). `codeLength` is a one-time
  code field (mono, digits grouped by four, `onSubmit({ code })` with digits only); form mode takes
  `children` after the password; `embedded` renders a div inside an AppShell. Never two ways in
  on one page.
- `PeoplePage` is who can sign in, and where: access follows the person, never the device. A header
  with the one primary (`Invite person`, a filled plus icon), an optional Invitation tile with the
  one-time code (PairingCode, renew, cancel), and an Accounts tile of rows, one per
  person but you (a person marked `you` is left out), role and device count, then two fixed 32
  columns on every row, devices included: a danger trash to remove, and a chevron for devices
  (an empty `span.hw-people-slot` is held where a row has none). With `onResetPassword` the
  chevron also opens a Password row with a refresh-cw "Reset password of <name>"; `reset` shows
  the one-time code as a "Password reset for <name>" tile, like the invitation; `hostOnly` ("studio-pc")
  disables Invite and Reset and says to do it there. `SetPasswordDialog` (`userName`, `change`,
  `askCurrent`, `currentError`, `isPending`, `minLength` 10, `onSet(next, current)`, `onCancel`,
  `note`) sets or changes a password: the commit stays disabled until the two fields match, and one
  line under the second says what is missing. `AccountPage` (`userName`, `devices`,
  `onChangePassword`, `onEndSession`, `hasPassword`) is the signed-in person's own page; its
  `onChangePassword(next, current)` may return an error string or a promise of one, which keeps the
  dialog open with it under the current password (`useChangePassword` holds that for a page).
  SignInPage `onForgot` adds a ghost "Forgot password?" after the action. A TabBar item with a
  `menu` is not a tab: its entries list as a group in More. Removing a person and signing a device out both open an alert Dialog with Cancel
  focused and the commit named; `removeNote` says what the app deletes with a person. The code,
  sessions and passwords are the host library's job. SignInPage `staySignedIn` adds an unticked
  "Stay signed in" tick and `onSubmit` gets `stay`. ListRow takes `className`.
- Needs you is a list of things to do: every row ends in exactly one action (an icon button named
  in full when it is a standard action, else a labelled button) and no row opens on press. The
  row's `id` is the drill id, put on the action so back returns focus to it.
- A pending Button keeps its box: the spinner takes the icon's place at the icon's size, or sits
  over the label, which stays (hidden) and keeps the button's name. `IconButton danger` is the
  `trash-2` Remove or Delete in danger text, and `IconButton variant="primary"` (40) is a page's
  one primary action when a standard icon says it. A Property with `changed` and `onReset` follows an
  item's own default, for a selection whose items each have one.
- `flush` on the AppShell keeps the same content element (display: contents), so toggling it
  never remounts the page.
- Table: `current` marks the row a detail or the inspector shows (accent-subtle, a 2 accent edge,
  `aria-current`); `onRowAction` makes rows open by click, Enter or Space. A tile body holding only
  a table has no padding, and the table drops its own frame.
- Settings is a standard page too: `SettingsPage` takes the app's sections of setting rows, then
  adds Appearance (theme, colour vision mode; `appearance` with `theme`/`onTheme` and
  `vision`/`onVision` to hold them in the app) and About (product, version, platform, copyright,
  and Third-party notices in a dialog). Dialog takes `onClose` and `closeLabel`.
- Standard pieces, the same in every app: `Facts` for read-only details, `NeedsYouTile` first on
  the overview (nothing when nothing needs the person), `Checklist` for steps and checks,
  `StripJob` for the one running job in the strip, `PairingCode` for a one-time code. One way each
  across apps: state words from StateLabel, removal undoable with a toast or confirmed, settings
  that apply at once, one name per place, PageHeader `back`, and the shared shortcuts (Ctrl K
  search, Ctrl N add, Ctrl B sidebar, Ctrl Alt B inspector, Alt Left back, Ctrl , settings).
- Taking a log or a table elsewhere is an icon button, `download`, "Export to CSV", at the right
  of the search. It exports what is shown, so a search narrows the file too.
- Turning a thing on or off at once (sharing a device, allowing a computer) is a Switch on its row
  or in the detail header, not a pair of buttons. Buttons stay for bulk and destructive actions.
- Content sets no max width of its own and is never centred.
- Settings and security pages are full-width tiles of setting rows: `SettingsList` of
  `SettingRow`s, the name in 500 with its help under it, the control at the right (Switch, Select,
  SegmentedControl, a button that opens a dialog, a CopyValue), wrapping under the text below 520.
  A plain list rather than the `List` listbox, since every row holds a control. A control that
  shows its own text (a Button) keeps that as its name, and the title and help only describe it; a
  control without a name (a bare Switch) is named by the row's title. `TileStack` stacks the
  tiles 24 apart.
- An id, address or key people copy is a `CopyValue` next to it: mono text and a copy button that
  turns into a check and "Copied" for 1.5 s. No toast, and no Copy button among the page actions.
  A secret people copy (a server key) is `masked`: its first and last four with bullets between,
  read as hidden, copied in full; `revealable` adds Show and Hide. Rows in one tile line up: an
  action only some rows have is quiet, as `onEdit` is, a pencil left of the value that takes no
  space and shows on row hover or focus. `IconButton quiet` is the version that keeps its space
  so every row ends alike: hidden until its row is hovered or focused, always on touch.
- Ordinary text in a value slot wraps. A value that cannot wrap sensibly (a fingerprint, a key, an
  address) is one line that shortens with an ellipsis and shows its full text in a tooltip when it is
  cut, also on keyboard focus: a `CopyValue` always does, and plain text of that kind goes in `Value`.
  A path takes `path` (on `Value` and `CopyValue`): its own full-width line under the row's name and
  help, monospace, breaking after every separator, never cut; Copy and the pencil stay on the name line.
- Nothing moves when it changes: group rows and cards by something their control cannot change,
  and nothing changes width while pending. A pending `Switch` shows its spinner on the thumb and is
  `aria-busy`; one with no visible label (the row already says the state) takes `aria-label`.
- Inside a tile, a Table drops its own frame and figures are `KpiCard bare`. A drill link that is
  not a list row (a tile title, a Needs you item) is a `DrillLink`.
- Tooltips are fixed to the window, placed from their anchor, flip above near the bottom edge and
  close on any scroll, so they never grow a table's or a pane's scroll area.
- Every icon-only control has a tooltip, the dialog's close (with Esc), the toast's dismiss, the
  search's clear and the breadcrumb's hidden levels included. Only window caption buttons skip it,
  as the system does. Copy is always an icon (CopyValue), never a labelled Copy button.

## Develop

From `src/`: `pnpm build`, `pnpm test`, `pnpm gallery` (Storybook), `pnpm e2e` (Playwright against
the built gallery). The story Overview/All themes renders every component in all four themes.

`src/styles/bundle.css` is a copy of the design system's `components/bundle.css`. Change it there
first; its header lists what differs here.
